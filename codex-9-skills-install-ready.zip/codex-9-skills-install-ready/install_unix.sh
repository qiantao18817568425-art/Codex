#!/usr/bin/env bash
set -euo pipefail
TARGET="$HOME/.agents/skills"
mkdir -p "$TARGET"
cp -R ./.agents/skills/* "$TARGET/"
echo "Installed Codex 9 Skills to $TARGET"
