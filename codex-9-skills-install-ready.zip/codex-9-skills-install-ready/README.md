# Codex 9 Skills Install Ready

把本目录中的 `.agents/skills` 复制到你的用户目录或项目仓库即可。

## Windows PowerShell

```powershell
Copy-Item -Recurse .\.agents\skills\* "$env:USERPROFILE\.agents\skills" -Force
```

## macOS / Linux

```bash
mkdir -p "$HOME/.agents/skills"
cp -R ./.agents/skills/* "$HOME/.agents/skills/"
```

## 仓库级安装

在项目仓库根目录复制：

```bash
mkdir -p .agents/skills
cp -R /path/to/codex-9-skills-install-ready/.agents/skills/* .agents/skills/
```
