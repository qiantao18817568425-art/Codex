$target = Join-Path $env:USERPROFILE ".agents\skills"
New-Item -ItemType Directory -Force $target | Out-Null
Copy-Item -Recurse -Force ".\.agents\skills\*" $target
Write-Host "Installed Codex 9 Skills to $target"
