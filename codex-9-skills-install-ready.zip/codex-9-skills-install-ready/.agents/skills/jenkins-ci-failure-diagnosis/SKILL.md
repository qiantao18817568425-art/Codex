---
name: jenkins-ci-failure-diagnosis
description: Diagnose Jenkins or CI build failures, Android/AOSP release logs, signing failures, HSM, cert/key, image packaging, DPM/firmware build, compiler/test failures.
---

# Jenkins CI Failure Diagnosis

Use this skill for Jenkins, CI, build, signing, image packaging, release pipeline, and Android/AOSP build failures.

## Analysis flow

1. Find the first real error, not the last cascading error.
2. Identify the failed stage, command, target image/module, and workspace path.
3. Separate warnings that can be ignored from fatal errors.
4. Check cert/key/HSM/signing/image packaging details when present.
5. Identify owner: build system, security/signing, module owner, infra, dependency.
6. Provide exact next commands or files to inspect.

## Output format

1. Conclusion
2. First fatal error
3. Failed stage/module/image
4. Why it failed
5. Warnings that can be ignored
6. Owner and next action
7. Suggested Jenkins/log grep commands
