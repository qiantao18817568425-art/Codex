---
name: black-flower-freeze-diagnosis
description: Diagnose black screen, flower screen, white/green screen, freeze, stuck frame, and cockpit display deadlock issues. Use when the user mentions 黑屏、花屏、白屏、绿屏、死机、卡死、黑花死卡、黑灰卡闪.
---

# 黑花死卡诊断

Use this skill to classify and diagnose cockpit display abnormality issues.

## Classification dimensions

1. Abnormal system: Android, Yocto/Linux, QNX, MCU, ADCC/J6M, display panel
2. Technical domain: BSP, FW, APP, HMI, Display, Power, Video, Input
3. Severity: critical, high, medium, low
4. Abnormal module: backlight, panel, SurfaceFlinger, HWC, AVM, Launcher, SystemUI, video stream, power state
5. Failure type: black screen, flower screen, white screen, green screen, freeze, flash, stuck frame
6. Fault details: event time, duration, trigger, recovery behavior, recurrence

## Diagnosis flow

1. Confirm whether backlight is on or off.
2. Confirm whether HWC/Framebuffer/SurfaceFlinger is still producing frames.
3. Confirm whether Yocto has AVM/video stream output.
4. Confirm whether Android top app/window is abnormal.
5. Confirm whether power state or screen policy changed.
6. Confirm whether display panel/video lock reports abnormality.
7. Decide whether this is display hardware, video source, compositor/layer, Android app/window, or power policy.

## Output format

- One-sentence conclusion
- Timeline
- Fault classification table
- Evidence and exclusions
- Suspected owner
- Suggested new log points /埋点
