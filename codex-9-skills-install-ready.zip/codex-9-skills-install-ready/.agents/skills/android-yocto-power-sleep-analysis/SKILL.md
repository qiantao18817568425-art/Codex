---
name: android-yocto-power-sleep-analysis
description: Analyze Android + Yocto/Linux + MCU power state, STR sleep, wakeup, suspend failure, repeated wake, PowerManager.wakeUp, display power, KL15/ACC/D1-D4 state issues.
---

# Android Yocto Power Sleep Analysis

Use this skill for STR, suspend/resume, wakeup, sleep failure, repeated pull-up, power state, and display power analysis.

## Key questions

1. Did the system actually enter suspend/STR?
2. Was suspend blocked or interrupted?
3. Who triggered wakeup?
4. Did Android call PowerManager.wakeUp?
5. Did kernel report wakeup source or suspend failure?
6. Did MCU send STR command and then receive an interrupt/state change?
7. Did screen/backlight policy change unexpectedly?

## Common keywords

- PowerManager.wakeUp
- DisplayPowerController
- WindowManager
- suspend entry / suspend exit
- wakeup source
- kernel wakeup
- MCU STR
- PwrMode
- KL15 / ACC
- D1 / D2 / D3_SA / D3_Sleep / D4
- screen on/off reason
- IC_SCREEN_SET

## Output format

1. Sleep/wakeup conclusion
2. Timeline with Android, Yocto, kernel, MCU correlation
3. Wakeup source or blocker
4. Whether the wake was expected or abnormal
5. Evidence table
6. Next owner/action
