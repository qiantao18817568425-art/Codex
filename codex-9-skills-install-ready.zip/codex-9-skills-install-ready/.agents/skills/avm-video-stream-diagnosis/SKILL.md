---
name: avm-video-stream-diagnosis
description: Diagnose AVM/360 camera no-video, black image, lag, frame drop, four-camera stream loss, RTSP/video lock, ThunderAVM, Yocto display path, ADCC/J6M reset, FOG, overlay/layer issues in automotive cockpit systems.
---

# AVM Video Stream Diagnosis

Use this skill when the user asks to analyze AVM/360 panoramic camera issues, including no image, black image, delayed image, lag, frozen frame, missing camera stream, low frame rate, video lock failure, ADCC/J6M reset, Yocto AVM no display, ThunderAVM problems, or layer/overlay conflicts.

## Scope

This skill focuses on the AVM video path and its surrounding dependencies:

1. User trigger: reverse gear, AVM button, parking scene, APA/RPA request, camera activation.
2. Android side: top app/window, request source, service lifecycle, overlay/layer relation.
3. Yocto/Linux side: ThunderAVM, MessageCenter, AVM service, RTSP/video pipeline, display policy.
4. Camera/video side: four-camera stream, frame rate, video lock, frame drop, black frame, timeout.
5. ADCC/J6M side: camera source status, reset policy, low frame-rate reset loop.
6. Display side: HWC/Framebuffer, FOG, layer order, video plane, screen/backlight policy.

## Diagnosis principles

1. Build a precise timeline before assigning responsibility.
2. Distinguish “AVM not requested”, “AVM requested but Yocto not started”, “Yocto started but no stream”, “stream exists but not displayed”, and “displayed but covered by other layer”.
3. Check four camera streams separately. Do not treat “AVM has stream” as equal to “all four streams are normal”.
4. Identify whether the issue is one-time drop, continuous no stream, repeated reset, or layer/display conflict.
5. Separate evidence from assumption. If the logs cannot prove a camera stream exists, say so clearly.
6. Do not blame ADCC/J6M, Yocto, Android, or display panel without matching evidence.

## Common keywords

### AVM / application

- ThunderAVM
- AVM
- AroundView
- 360
- parking
- reverse
- RVC
- APA
- RPA
- MessageCenter
- service start
- service stop
- request AVM

### Video stream

- RTSP
- video lock
- frame rate
- fps
- frame drop
- no frame
- black frame
- stream timeout
- camera timeout
- decoder
- buffer
- BufferData
- video pipeline

### Four camera streams

- front camera
- rear camera
- left camera
- right camera
- ch0 / ch1 / ch2 / ch3
- camera0 / camera1 / camera2 / camera3
- four-way stream
- 四路摄像头
- 单路无流
- 漏帧
- 掉流

### ADCC / J6M

- ADCC
- J6M
- reset
- low frame rate
- frame rate below threshold
- continuous reset
- ISP
- deserializer
- SerDes

### Display / layer

- HWC
- Framebuffer
- SurfaceFlinger
- overlay
- layer
- FOG
- video plane
- screen on/off reason
- IC_SCREEN_SET
- backlight

## Required analysis flow

### 1. Confirm the user-visible phenomenon

Classify the issue first:

| Type | Meaning |
|---|---|
| AVM not launched | User triggered AVM, but AVM service/window did not start |
| AVM launched but no image | AVM UI exists, but video content is black/empty |
| One camera missing | Some views exist, but one camera stream is absent |
| Frame drop / lag | Video exists but is delayed, frozen, or low FPS |
| Layer covered | Video is produced but hidden by another layer/window |
| Display path abnormal | HWC/Framebuffer/FOG/video plane abnormal |
| ADCC reset loop | Low FPS or no stream causes repeated reset |

### 2. Build timeline

At minimum, align these events:

1. Trigger time: reverse gear / AVM button / scene request.
2. Android request time: app/window/service sends request.
3. Yocto receives request time.
4. ThunderAVM/AVM pipeline start time.
5. First video lock / first frame time.
6. Four camera stream status time.
7. Abnormal frame/drop/reset time.
8. Recovery or exit time.

### 3. Check whether AVM was requested

Confirm:

- Was there a reverse/AVM/parking request?
- Which side initiated it: Android, Yocto, MCU, ADCC, or scene service?
- Did the request reach Yocto/ThunderAVM?
- Was there a state mismatch: Android thinks AVM opened, Yocto did not receive, or Yocto already exited?

### 4. Check stream availability

For each camera path, look for:

- Stream start
- Video lock
- Frame rate
- Drop count
- Timeout
- Buffer availability
- Reset/reconnect

Output the result as a four-stream table:

| Camera | Stream started | Video lock | FPS/frame evidence | Abnormal evidence | Judgment |
|---|---|---|---|---|---|
| Front | Unknown | Unknown | Unknown | Unknown | Need evidence |
| Rear | Unknown | Unknown | Unknown | Unknown | Need evidence |
| Left | Unknown | Unknown | Unknown | Unknown | Need evidence |
| Right | Unknown | Unknown | Unknown | Unknown | Need evidence |

### 5. Check whether stream exists but display is blocked

If logs show frames are produced, check:

- Is AVM layer created?
- Is AVM layer visible?
- Is another overlay above it?
- Is HWC/Framebuffer still refreshing?
- Did FOG or video plane report an error?
- Is screen/backlight policy off while AVM is active?

### 6. Check ADCC/J6M reset logic

If low FPS or no stream appears:

- Did ADCC/J6M trigger reset?
- What threshold triggered reset? Example: FPS below threshold for N times.
- Did reset recover the stream?
- Did reset repeat without max count?
- Was the issue caused by source loss or by reset policy making it worse?

### 7. Assign responsibility boundary

Use this rule:

| Evidence | Likely responsibility domain |
|---|---|
| Android did not send AVM request | Android APP/HMI/scene service |
| Android sent request but Yocto did not receive | Domain communication / MessageCenter |
| Yocto received request but ThunderAVM did not start | Yocto AVM service |
| ThunderAVM started but no video lock | Camera/ADCC/J6M/video source |
| Video lock and frames exist but screen black | Display/HWC/layer/video plane |
| Only one camera missing | Camera channel/SerDes/ADCC specific path |
| Repeated low-FPS reset loop | ADCC/J6M reset strategy or source instability |
| AVM visible but covered | Layer/window policy |

## Output format

Always use this structure:

1. **Conclusion**
   - One sentence: most likely cause and confidence level.
2. **Timeline**
   - Time, system, event, meaning.
3. **AVM request chain**
   - Trigger → Android/scene → Yocto → ThunderAVM → video pipeline → display.
4. **Four-camera stream table**
   - Front/rear/left/right status.
5. **Evidence**
   - Key log lines or patterns.
6. **Exclusions**
   - What can be ruled out and why.
7. **Responsibility boundary**
   - Android / Yocto / ADCC-J6M / display / domain communication.
8. **Next actions**
   - Owner, action, expected output.
9. **Recommended log points / 埋点**
   - Missing evidence to add.

## Recommended log points / 埋点

Add or request these logs for future AVM diagnosis:

1. AVM request received time, request source, request reason.
2. Yocto ThunderAVM state transition: idle → starting → streaming → stopping → error.
3. Four-camera stream status: channel, lock state, FPS, drop count, timeout count.
4. First frame timestamp for each camera.
5. Last frame timestamp for each camera.
6. ADCC/J6M reset reason, reset count, reset result, max reset protection.
7. RTSP connection state and reconnect reason.
8. HWC/Framebuffer layer visible state and z-order.
9. FOG/video plane error code.
10. AVM exit reason: user exit, gear change, timeout, service crash, request cancellation.

## Standard judgment wording

Use these patterns:

- “Current evidence supports that AVM was requested, but Yocto did not start ThunderAVM; responsibility should first go to Yocto AVM service / domain communication for confirmation.”
- “Current evidence supports that ThunderAVM started and video frames existed, so the first suspect is display layer/HWC/video plane rather than camera source.”
- “Current evidence is insufficient to determine whether all four camera streams existed. The next step is to provide channel-level video lock/FPS logs.”
- “This looks like a repeated ADCC/J6M reset loop triggered by low FPS. The next check is whether the reset policy has max retry protection and whether the source recovers after reset.”
