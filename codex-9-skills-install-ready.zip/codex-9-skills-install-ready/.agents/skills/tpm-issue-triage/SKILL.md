---
name: tpm-issue-triage
description: Convert vague technical issues into TPM triage output: phenomenon, impact, boundary, suspected domains, owner, next action, deadline, risk, escalation. Use for multi-team automotive cockpit issues with unclear responsibility.
---

# TPM Issue Triage

Use this skill when a technical issue is unclear and needs TPM-level organization rather than immediate coding.

## TPM responsibility

TPM should not replace architect/module owner/root-cause owner. TPM must make the issue executable by defining phenomenon, impact, boundary, evidence, suspected owners, next actions, deadline, and escalation path.

## Output format

1. Problem phenomenon
2. Occurrence time / frequency / trigger
3. Impact scope
4. Current evidence
5. Initial boundary and suspected domains
6. Next action owner table
7. Deadline and verification criteria
8. Risk level
9. Escalation decision

## Rules

- Do not assign root cause without evidence.
- Distinguish first-analysis owner from final root-cause owner.
- Use clear action verbs: check, reproduce, provide log, confirm, patch, verify, close.
- Make every next step have an owner and expected output.
