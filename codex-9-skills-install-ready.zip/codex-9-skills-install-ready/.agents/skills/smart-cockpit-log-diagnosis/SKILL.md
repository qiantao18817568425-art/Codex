---
name: smart-cockpit-log-diagnosis
description: Analyze automotive smart cockpit logs across Android logcat, Yocto syslog, kernel logs, tombstones, db_history, gz/7z/txt files. Use for black screen, AVM no video, Android killed, sleep/wakeup, touch, display, or multi-domain issue triage.
---

# Smart Cockpit Log Diagnosis

Use this skill when the user asks to analyze vehicle cockpit logs involving Android, Yocto/Linux, QNX, MCU, display, AVM, touch, wake/sleep, crash, tombstone, or multi-domain responsibility.

## Required behavior

1. Build a timeline first. Do not jump to root cause before aligning timestamps across files.
2. Identify the target event window and whether log timestamps need correction.
3. Classify involved domains: Android, Yocto/Linux, QNX, MCU, ADCC/J6M, display panel, app/HMI, BSP, FW.
4. Extract evidence lines for each hypothesis.
5. Separate conclusion, evidence, exclusions, and next actions.
6. Be explicit when evidence is insufficient.

## Output format

Use this structure:

1. Conclusion
2. Key timeline
3. Evidence table
4. Suspected responsibility domain
5. Exclusions
6. Next owner/action
7. Missing logs or extra commands needed

## Common keywords

- Android: AndroidRuntime, tombstone, ActivityManager, WindowManager, SurfaceFlinger, InputDispatcher, InputReader, PowerManager.wakeUp, DisplayPowerController
- Yocto/Linux: syslog, kernel, video lock, frame rate, MessageCenter, IC_SCREEN_SET, screen on/off reason, panel brightness
- Power: suspend entry, suspend exit, wakeup source, STR, KL15, ACC, D1, D2, D3_SA, D3_Sleep, D4
- AVM: ThunderAVM, RTSP, four camera streams, ADCC, J6M, FOG, video lock
