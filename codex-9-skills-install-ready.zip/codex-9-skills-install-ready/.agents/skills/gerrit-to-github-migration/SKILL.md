---
name: gerrit-to-github-migration
description: Plan migration from Gerrit linear commit workflow to GitHub Enterprise, including PR process, branch strategy, code review, CI, large AOSP repos, permissions, Copilot pilot, and governance.
---

# Gerrit to GitHub Migration

Use this skill when planning or evaluating a migration from Gerrit to GitHub Enterprise or introducing PR-based workflows.

## Analysis areas

1. Current workflow: Gerrit change review, linear commits, repo size, CI hooks, permissions.
2. Target workflow: PR review, protected branches, CODEOWNERS, Actions/Jenkins integration, release branches.
3. Risk: AOSP huge repos, history size, storage, access control, traceability, audit, network.
4. Pilot: select 1-2 repositories, 5-10 Copilot/GitHub users, define success metrics.
5. Rollout: migration phases, training, governance, fallback.

## Output format

1. Migration conclusion
2. Current vs target workflow table
3. Pilot plan
4. Technical risks and mitigations
5. Process changes
6. Cost/infra questions
7. Decision checklist
