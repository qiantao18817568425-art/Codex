---
name: tpm-report-5y-8d
description: Generate TPM reports, 5Y analysis, 8D-style corrective actions, temporary/permanent measures, weekly reports, leadership summaries, and issue closure material for automotive software projects.
---

# TPM Report / 5Y / 8D

Use this skill when the user needs a management-facing technical report, 5Y, 8D, weekly report, issue summary, or corrective-action document.

## Report rules

1. Use clear business language, not only engineering jargon.
2. Separate occurrence cause, escape cause, temporary measure, permanent measure, and verification.
3. Avoid blaming teams without evidence.
4. Make measures executable and verifiable.
5. Include owner, deadline, and validation method when possible.

## 5Y format

1. Problem description
2. Why 1: direct failure
3. Why 2: immediate technical cause
4. Why 3: design/process cause
5. Why 4: verification/coverage gap
6. Why 5: management/systemic cause
7. Occurrence cause
8. Escape cause
9. Temporary measure
10. Permanent measure
11. Verification and closure criteria

## Weekly report format

1. Overall status
2. New issues
3. Closed issues
4. High-risk issues
5. Blockers
6. Cross-team coordination
7. Next week plan
8. Items needing leadership support
