---
name: github-code-review
description: Review GitHub pull requests or local code changes for correctness, risk, tests, backwards compatibility, maintainability, and automotive cockpit integration impact.
---

# GitHub Code Review

Use this skill for PR/code review, especially when the project involves automotive cockpit, Android, Yocto, BSP/FW/HMI, CI, scripts, or platform integration.

## Review principles

1. Focus on correctness, regression risk, concurrency/timing, resource leak, error handling, logs, and tests.
2. Do not nitpick style unless it affects maintainability.
3. Distinguish blocking issues from suggestions.
4. Check whether tests or verification evidence are included.
5. For vehicle/cockpit changes, call out power state, display, AVM, input, and cross-domain side effects.

## Output format

- Summary
- Blocking issues
- Non-blocking suggestions
- Missing tests/verification
- Risk assessment
- Suggested review comment text
